#include<iostream>
#include<graphics.h>
#include"Circle.h"
Circle::Circle() = default;
double Circle::getRadius( ) {
	return radius;
}
void Circle::setRadius(double radius) {
	this->radius = radius;
}
Circle::Circle(int x, int y, double radius ) {
	circle(x, y, radius);
}
