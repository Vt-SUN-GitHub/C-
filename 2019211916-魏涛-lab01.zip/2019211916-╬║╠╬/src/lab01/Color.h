#pragma once
#include<iostream>
#include<graphics.h>
enum Ccolor 
{
	WHITE, BLACK, BLUE, GREEN, RED, BROWN, YELLOW, DARKGRAY,
};
class Color {
private:
	int x{ 0 }, y{ 0 }, z{ 0 };
	bool is_filled = false;
	
public:
	Color();
	Color(Ccolor color1, Ccolor color2);
	int getRGBr();
	int getRGBg();
	int getRGBb();
	void setRGB(int x, int y, int z);
	void setIsFilled(bool is_filled);
	bool getIsFilled();
};