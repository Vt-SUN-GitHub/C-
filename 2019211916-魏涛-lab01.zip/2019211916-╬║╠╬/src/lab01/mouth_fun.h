#pragma once
#include<graphics.h>
int mouse_fun(int mouse_number, int beforeline)//ִ����������
{
	for (; is_run(); delay_fps(60))//ѭ����ʹ
	{
		mouse_msg file = { 0 };
		while (mousemsg())
			file = getmouse();
		int x, y;
		mousepos(&x, &y);
		for (int i = 1; i <= mouse_number; i++)
		{
			if (x > 20 && x < 200 && y < 40 * (i + beforeline) + 20 && y>40 * (i + beforeline))
			{
				setcolor(RGB(0xFF,0xFF,0xFF));
				rectangle(19, 40 * (i + beforeline) - 1, 200, 40 * (i + beforeline) + 20);
				if (file.is_down() == true)
					return i;//���ش������ֵ����Ӧ��ѡ���ѡ��
			}
			else
			{
				setcolor(getbkcolor());
				rectangle(19, 40 * (i + beforeline) - 1, 200, 40 * (i + beforeline) + 20);
			}
		}
	}
}