﻿#include<graphics.h>
#include"main.h"
#include"Circle.h"
#include"Color.h"
#include"Controller.h"
#include"Fillpoly.h"
#include"Line.h"
#include"Point.h"
#include"Rectangle.h"
#include"mouth_fun.h"
#include"Changecolor.h"

#define allnumber 20//便于将数组的初始化；
void Drawing() {//用于作画的主体代码部分
	bar(0, 0, 370, 1800);
	menu_2();//显示选择图形的菜单
	char padding_1[allnumber]; char str_1[allnumber]; int itr_1[allnumber]; int i{ 0 }; Circle c1;
	char padding_2[allnumber]; char str_2[allnumber]; int itr_2[allnumber]; int j{ 0 }; RectangleW r1;
	char padding_3[allnumber]; char str_3[allnumber]; int itr_3[allnumber]; int k{ 0 }; Line l1;
	char padding_4_1[100]; char padding_4_2[100]; char str_4_1[100]; char str_4_2[100]; int itr_4_1[100]; int itr_4_2[100]; int l{ 0 }; int m{ 0 }; int n = 0; Fillpoly f1;
	/*
	padding系列是存储是否改变边线颜色的0-1选项；
	str系列是存储每个图形的坐标；
	itr系列是存储将存储在str的那些char型数据转化为整形的存储数组；
	整形数据0都是用于common函数；
	*/
	int z = mouse_fun(6, 0);//对于六个选项的鼠标操作；
	switch (z) {//不同情况的分类；
	case 1://z是整数；
		inputbox_getline("请选择是否改变边线颜色",
			"输入1代表选择改变（初始颜色为白色）输入其它表示不改变", padding_1, sizeof(padding_1) / sizeof(padding_1[0]));
		if (padding_1[0] == '1') {
			ChangeForecolor();
		}
		inputbox_getline("请往下面看\n",
			"请输入三个数据，顺序为圆心x坐标，圆心y坐标，半径长度(数字之间用英文逗号进行分割)",
			str_1, sizeof(str_1) / sizeof(str_1[0]));
		common(itr_1, i, str_1);//转化为int型数据
		c1.setPointX((itr_1[0] + 370)); c1.setPointY(itr_1[1]); c1.setRadius(itr_1[2]);
		Circle::Circle(c1.getPointX(), c1.getPointY(), c1.getRadius());
		break;
	case 2:inputbox_getline("请选择是否改变边线颜色",
		"输入1代表选择改变（初始颜色为白色）输入其它表示不改变", padding_2, sizeof(padding_2) / sizeof(padding_2[0]));
		if (padding_2[0] == '1') {
			ChangeForecolor();//改变边线颜色；
		}
		inputbox_getline("请往下面看\n",
			"请输入三个数据，顺序为矩形左上角点的坐标（x和y）和左下角点的坐标（x和y）(数字之间用英文逗号进行分割)",
			str_2, sizeof(str_2) / sizeof(str_2[0]));
		common(itr_2, j, str_2);
		r1.setPointX((itr_2[0] + 370)); r1.setPointY(itr_2[1]); r1.setRtgSizeL(itr_2[2] + 370); r1.setRtgSizeW(itr_2[3]);//将数据用set函数存进对象中；
		RectangleW::RectangleW(r1.getPointX(), r1.getPointY(), r1.getRtgSizeL(), r1.getRtgSizeW());//用构造函数画出图形；
		break;
	case 3:inputbox_getline("请选择是否改变边线颜色",
		"输入1代表选择改变（初始颜色为白色）输入其它表示不改变", padding_3, sizeof(padding_3) / sizeof(padding_3[0]));
		if (padding_3[0] == '1') {//判断输入的是否为字符‘1’；
			ChangeForecolor();
		}
		inputbox_getline("请往下面看\n",
			"请输入三个数据，顺序为直线起点的坐标（x和y）和终点的坐标（x和y）(数字之间用英文逗号进行分割)",
			str_3, sizeof(str_3) / sizeof(str_3[0]));
		common(itr_3, k, str_3);
		l1.setx1((itr_3[0] + 370)); l1.sety1(itr_3[1]); l1.setx2(itr_3[2] + 370); l1.sety2(itr_3[3]);//将数据用set函数存进对象中；
		Line::Line(l1.getx1(), l1.gety1(), l1.getx2(), l1.gety2());//用构造函数画出图形；
		break;
	case 4:inputbox_getline("请选择是否改变边线颜色",
		"输入1代表选择改变（初始颜色为白色）输入其它表示不改变", padding_4_1, sizeof(padding_4_1) / sizeof(padding_4_1[0]));
		if (padding_4_1[0] == '1') {//判断输入的是否为字符‘1’；
			ChangeForecolor();
		}
		inputbox_getline("请选择是否改变填充颜色",
			"输入1代表选择改变（初始颜色为黑色）输入其它表示不改变", padding_4_2, sizeof(padding_4_2) / sizeof(padding_4_2[0]));
		if (padding_4_2[0] == '1') {//判断输入的是否为字符‘1’；
			ChangeFillColor();
		}
		inputbox_getline("请选择多边形边数\n",
			"请输入您所要画的多边形的边数，输入完毕后请按回车键结束输入",
			str_4_1, sizeof(str_4_1) / sizeof(str_4_1[0]));
		common(itr_4_1, l, str_4_1);
		f1.setNumpoints(itr_4_1[0]);
		inputbox_getline("请选择各点坐标\n",
			"请输入您所要画的多边形顶点的坐标,以逗号进行分割（逗号之间必须要有数据），n边形需要输入2n个坐标哦，完成后按回车结束输入",
			str_4_2, sizeof(str_4_2) / sizeof(str_4_2[0]));
		common(itr_4_2, m, str_4_2);
		for (int i = 0; i < (2 * f1.getNumpoints()); i++) {//因为菜单的存在，需要将所有的x坐标在原有基础上+370；
			n = 2 * i;
			itr_4_2[n] += 370;
		}
		f1.setPoints(itr_4_2);
		fillpoly(f1.getNumpoints(), itr_4_2);
		break;
	case 5://五选项是返回上一级，如果不作为，则根据主函数的循环，它会重新循环一遍menu_1；
		break;
	defaut:
		exit(0);//退出画板；
		break;

	}
}
int main() {
	int numMenu_1{ 0 };//判断循环退出的变量条件；
	initgraph(-1, -1);
	do {
		setfontbkcolor(RGB(0x00, 0x00, 0x00));//设置字体的背景色；
		bar(0, 0, 370, 1800);//使得菜单可以更新；，并且所画图形不会消失；
		menu_1();
		int z = mouse_fun(4, 0);//执行鼠标操作；
		numMenu_1 = z;
		switch (z) {
		case 1:
			Drawing();//上方的作画函数；
			break;
		case 2:
			exit(0);
			break;
		case 3:ChangeBkcolor();//更改背景颜色；
			break;
		default:
			cleardevice();//清屏操作；
			break;
		}
	} while (numMenu_1 != 2);//如果不点击退出画板，则程序不会退出！
	return 0;
}
