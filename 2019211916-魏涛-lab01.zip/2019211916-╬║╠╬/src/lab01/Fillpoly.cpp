#include<iostream>
#include<graphics.h>
#include<array>
#include"Fillpoly.h"
Fillpoly::Fillpoly() = default;
Fillpoly::Fillpoly(int numpoints, int* points) {
		fillpoly(numpoints, points);
}
void Fillpoly::setNumpoints(int numpoints) {
	this->numpoints = numpoints;
}
int Fillpoly::getNumpoints() {
	return numpoints;
}
int Fillpoly::getPoints() {
	for (auto i : points) {
		return  points[i];
	}
}
void Fillpoly::setPoints(int* points) {
	for (int i = 0; i < numpoints; i++) {
		
		this->points[i] = points[i];
	}
}