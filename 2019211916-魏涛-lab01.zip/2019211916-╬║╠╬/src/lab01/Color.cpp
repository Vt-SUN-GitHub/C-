#include<iostream>
#include<graphics.h>
#include"Color.h"
Color::Color() = default;
Color::Color(Ccolor color_1, Ccolor color_2) {
	setcolor(color_1);
	setbkcolor(color_2);
}
int Color::getRGBr() {
	return x;
}
int Color::getRGBg() {
	return y;
}
int Color::getRGBb() {
	return z;
}
void Color::setRGB(int x, int y, int z) {
	this->x = x;
	this->y = y;
	this->z = z;
}
bool Color::getIsFilled() {
	return is_filled;
}
void Color::setIsFilled(bool is_filled) {
	this->is_filled = is_filled;
}