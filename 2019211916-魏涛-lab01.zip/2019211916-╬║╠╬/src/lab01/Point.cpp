#include<iostream>
#include<graphics.h>
#include"Point.h"
Point::Point() = default;
Point::Point(int x, int y) {

}
int Point::getPointX() {
	return x;
}
int Point::getPointY() {
	return y;
}
void Point::setPointX(int x) {
	this->x = x;
}
void Point::setPointY(int y) {
	this->y = y;
}