#include<iostream>
#include<graphics.h>
#include"Rectangle.h"
RectangleW::RectangleW() = default;
RectangleW::RectangleW(int x, int y, int RtgSizeL,int RtgSizeW) {
	rectangle(x, y, RtgSizeL, RtgSizeW);
}
int RectangleW::getRtgSizeL() {
	return RtgSizeL;
}
int RectangleW::getRtgSizeW( ) {
	return RtgSizeW;
}
void RectangleW::setRtgSizeL(int RtgSizeL) {
	this->RtgSizeL = RtgSizeL;
}
void RectangleW::setRtgSizeW(int RtgSizeW){
	this->RtgSizeW = RtgSizeW;
}