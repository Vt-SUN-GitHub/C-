#pragma once
#include<iostream>
#include<graphics.h>
#include<array>
#include"Color.h"
#include"Point.h"
#include"Controller.h"
using std::array;
class Fillpoly {
private:
	std::array<int, 100> points{ 0 };
	int numpoints{ 0 };
public:
	Fillpoly();
	Fillpoly(int numpoints, int* points);//�вι��캯�������ڻ�����Σ�
	void setPoints(int* points);
	int getPoints();
	void setNumpoints(int numpoints);
	int getNumpoints();
};