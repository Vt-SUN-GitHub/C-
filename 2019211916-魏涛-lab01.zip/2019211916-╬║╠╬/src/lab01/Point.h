#pragma once
#include<iostream>
#include<graphics.h>
class Point {
private:
	int x{ 0 }, y{ 0 };
public:
	Point();
	Point(int x, int y);
	int getPointX();
	int getPointY();
	void setPointY(int x);
	void setPointX(int y);
};