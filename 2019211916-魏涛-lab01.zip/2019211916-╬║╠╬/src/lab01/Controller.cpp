#include"Controller.h"
#include<graphics.h>
Controller::Controller() = default;
Controller::Controller(int x ) {
	if (x == 0) {
		exit(0);
	}
	else {

	}
}
void Controller::FontSize(int x) {
	setfont(x, 0, "TimesRoman");
}